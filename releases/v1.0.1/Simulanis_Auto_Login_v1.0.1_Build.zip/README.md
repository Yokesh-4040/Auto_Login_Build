# Simulanis Auto Login v1.0.1 Build Package

## Contents
- `Simulanis Auto Login.exe` - Main application executable
- `headless_config.json` - Configuration file for headless mode
- `Start Simulanis Login (GUI).bat` - GUI mode launcher
- `Start Simulanis Login.bat` - Headless mode launcher
- `Icons/` - Application icons
- `Logos/` - Branding assets

## Installation
1. Extract all files to your preferred location
2. Run the application using either:
   - `Simulanis Auto Login.exe` directly
   - `Start Simulanis Login (GUI).bat` for GUI mode
   - `Start Simulanis Login.bat` for headless mode

## Configuration
- Edit `headless_config.json` to customize headless mode settings
- Credentials are stored securely in the system keyring

## System Requirements
- Windows 10 or later
- Chrome browser installed
- .NET Framework 4.7.2 or later

## Notes
- This is the complete build package containing all necessary files
- For a simpler installation experience, use the installer package instead 